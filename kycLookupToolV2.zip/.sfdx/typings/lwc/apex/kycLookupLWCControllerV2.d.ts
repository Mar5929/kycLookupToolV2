declare module "@salesforce/apex/kycLookupLWCControllerV2.loadData" {
  export default function loadData(param: {contentDocumentId: any}): Promise<any>;
}
